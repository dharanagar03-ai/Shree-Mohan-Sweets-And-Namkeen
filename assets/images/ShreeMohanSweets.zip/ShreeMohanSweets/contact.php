<?php
include 'includes/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Shree Mohan Sweets and Namkeen</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<main class="container contact-page">
    <section class="page-heading">
        <h1>Contact Us</h1>
        <p>Questions, orders or feedback? We are here to help.</p>
    </section>

    <div class="contact-grid">
        <div class="contact-card">
            <h2>Reach Out</h2>
            <p>Phone: <a href="tel:+919313202040">+91 93132 02040</a></p>
            <p>WhatsApp: <a href="https://wa.me/919313202040" target="_blank">+91 93132 02040</a></p>
            <p>Instagram: <a href="https://www.instagram.com/shreemohansweets" target="_blank">@shreemohansweets</a></p>
            <p>Facebook: <a href="https://www.facebook.com/shreemohansweets" target="_blank">Shree Mohan Sweets</a></p>
            <p>Address: Near Market Square, Local Shopping Street</p>
        </div>

        <div class="contact-card">
            <h2>Send a Message</h2>
            <form action="<?= BASE_URL ?>/contact_process.php" method="POST" class="contact-form">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" required></textarea>
                </div>
                <button class="button button-primary" type="submit">Send Message</button>
            </form>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>