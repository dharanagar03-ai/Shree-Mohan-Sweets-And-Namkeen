<?php
session_start();
include('../includes/config.php');
include('../includes/functions.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit;
}

$product = null;
$categories = getCategories($conn);

if (!isset($_GET['id']) || !intval($_GET['id'])) {
    header('Location: ' . BASE_URL . '/admin/products.php');
    exit;
}

$product_id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param('i', $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
$stmt->close();

if (!$product) {
    header('Location: ' . BASE_URL . '/admin/products.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['product_name'] ?? '');
    $price = floatval($_POST['product_price'] ?? 0);
    $category_id = intval($_POST['product_category'] ?? 0);
    $featured = isset($_POST['featured']) ? 1 : 0;

    if (empty($name) || $price <= 0) {
        $error = 'Product name and price are required.';
    } else {
        $image_name = $product['image'];
        if (!empty($_FILES['product_image']['name'])) {
            $uploadDir = __DIR__ . '/../assets/images/';
            $image_name = time() . '_' . basename($_FILES['product_image']['name']);
            $targetFile = $uploadDir . $image_name;
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            $check = getimagesize($_FILES['product_image']['tmp_name']);
            if ($check === false) {
                $error = 'Uploaded file is not a valid image.';
            } elseif ($_FILES['product_image']['size'] > 2000000) {
                $error = 'Image file is too large.';
            } elseif (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                $error = 'Only JPG, JPEG, PNG, and GIF images are allowed.';
            } else {
                if (!move_uploaded_file($_FILES['product_image']['tmp_name'], $targetFile)) {
                    $error = 'Unable to upload image.';
                }
            }
        }

        if (empty($error)) {
            $stmt = $conn->prepare("UPDATE products SET name = ?, price = ?, category_id = ?, image = ?, featured = ? WHERE id = ?");
            $stmt->bind_param('sdiidi', $name, $price, $category_id, $image_name, $featured, $product_id);
            if ($stmt->execute()) {
                $success = 'Product updated successfully.';
                $product['name'] = $name;
                $product['price'] = $price;
                $product['category_id'] = $category_id;
                $product['image'] = $image_name;
                $product['featured'] = $featured;
            } else {
                $error = 'Unable to update product. Please try again.';
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Admin Panel</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<?php include('../includes/header.php'); ?>
<main class="container admin-page">
    <section class="page-heading">
        <h1>Edit Product</h1>
    </section>

    <?php if (!empty($error)): ?>
        <div class="error-box"><?php echo sanitize($error); ?></div>
    <?php endif; ?>
    <?php if (!empty($success)): ?>
        <div class="success-box"><?php echo sanitize($success); ?></div>
    <?php endif; ?>

    <form class="admin-form" action="<?= BASE_URL ?>/admin/edit-product.php?id=<?php echo sanitize($product_id); ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="product_name">Product Name</label>
            <input type="text" id="product_name" name="product_name" value="<?php echo sanitize($product['name']); ?>" required>
        </div>
        <div class="form-group">
            <label for="product_price">Price</label>
            <input type="number" id="product_price" name="product_price" step="0.01" value="<?php echo sanitize($product['price']); ?>" required>
        </div>
        <div class="form-group">
            <label for="product_category">Category</label>
            <select id="product_category" name="product_category" required>
                <option value="0">Choose category</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo sanitize($category['id']); ?>" <?php echo ($category['id'] == $product['category_id']) ? 'selected' : ''; ?>><?php echo sanitize($category['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="product_image">Image</label>
            <input type="file" id="product_image" name="product_image" accept="image/*">
            <?php if (!empty($product['image'])): ?>
                <p>Current image: <img src="<?= BASE_URL ?>/assets/images/<?php echo sanitize($product['image']); ?>" alt="Product Image" style="width:120px;border-radius:16px;margin-top:12px;"></p>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label>
                <input type="checkbox" name="featured" value="1" <?php echo !empty($product['featured']) ? 'checked' : ''; ?>> Featured Product
            </label>
        </div>
        <button class="button button-primary" type="submit">Save Changes</button>
    </form>
</main>
<?php include('../includes/footer.php'); ?>
</body>
</html>
