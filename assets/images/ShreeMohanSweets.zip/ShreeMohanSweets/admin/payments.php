<?php
session_start();
include('../includes/config.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit;
}

$query = "SELECT p.id AS payment_id, o.id AS order_id, o.customer_name, p.amount, p.method AS payment_method, p.status AS payment_status, p.created_at FROM payments p JOIN orders o ON p.order_id = o.id ORDER BY p.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - Admin Panel</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>

    <main class="container admin-page">
        <section class="page-heading">
            <h1>Payments</h1>
        </section>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo sanitize($row['order_id']); ?></td>
                        <td><?php echo sanitize($row['customer_name']); ?></td>
                        <td>₹<?php echo sanitize($row['amount']); ?></td>
                        <td><?php echo sanitize($row['payment_method']); ?></td>
                        <td><?php echo sanitize($row['payment_status']); ?></td>
                        <td><?php echo sanitize($row['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <?php include('../includes/footer.php'); ?>
</body>
</html>