<?php
session_start();
include('../includes/config.php');
include('../includes/functions.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit;
}

$total_products = getTotalProducts($conn);
$total_orders = getTotalOrders($conn);
$total_revenue = getTotalRevenue($conn);
$pending_orders = 0;
$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders WHERE status = 'Pending'");
if ($result) {
    $pending_orders = intval(mysqli_fetch_assoc($result)['total']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Shree Mohan Sweets and Namkeen</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>

    <main class="container admin-page">
        <section class="page-heading">
            <h1>Admin Dashboard</h1>
            <p>Monitor products, orders, offers and payments from one place.</p>
        </section>

        <div class="product-grid">
            <div class="admin-card">
                <h2>Total Products</h2>
                <p><?php echo sanitize($total_products); ?></p>
            </div>
            <div class="admin-card">
                <h2>Total Orders</h2>
                <p><?php echo sanitize($total_orders); ?></p>
            </div>
            <div class="admin-card">
                <h2>Pending Orders</h2>
                <p><?php echo sanitize($pending_orders); ?></p>
            </div>
            <div class="admin-card">
                <h2>Total Revenue</h2>
                <p>₹<?php echo number_format($total_revenue, 2); ?></p>
            </div>
        </div>

        <div class="admin-actions">
            <a class="button button-primary" href="<?= BASE_URL ?>/admin/products.php">Manage Products</a>
            <a class="button button-secondary" href="<?= BASE_URL ?>/admin/orders.php">Manage Orders</a>
            <a class="button button-secondary" href="<?= BASE_URL ?>/admin/payments.php">Payments</a>
            <a class="button button-secondary" href="<?= BASE_URL ?>/admin/offers.php">Manage Offers</a>
        </div>
    </main>

    <?php include('../includes/footer.php'); ?>
</body>
</html>