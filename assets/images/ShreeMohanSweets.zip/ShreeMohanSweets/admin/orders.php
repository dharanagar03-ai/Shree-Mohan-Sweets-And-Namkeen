<?php
session_start();
include('../includes/config.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];
    $stmt = $conn->prepare('UPDATE orders SET status = ? WHERE id = ?');
    $stmt->bind_param('si', $status, $order_id);
    $stmt->execute();
    $stmt->close();
}

$query = "SELECT o.id, o.customer_name, o.phone, o.address, o.total_amount, o.status, o.created_at FROM orders o ORDER BY o.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Admin Panel</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>

    <main class="container admin-page">
        <section class="page-heading">
            <h1>Customer Orders</h1>
        </section>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Order Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo sanitize($order['id']); ?></td>
                        <td><?php echo sanitize($order['customer_name']); ?></td>
                        <td><?php echo sanitize($order['phone']); ?></td>
                        <td>₹<?php echo sanitize($order['total_amount']); ?></td>
                        <td>
                            <form action="<?= BASE_URL ?>/admin/orders.php" method="POST">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="Pending" <?php echo ($order['status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Confirmed" <?php echo ($order['status'] === 'Confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                                    <option value="Delivered" <?php echo ($order['status'] === 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                                </select>
                                <input type="hidden" name="order_id" value="<?php echo sanitize($order['id']); ?>">
                            </form>
                        </td>
                        <td><?php echo sanitize($order['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <?php include('../includes/footer.php'); ?>
</body>
</html>