<?php
session_start();
include('../includes/config.php');
include('../includes/functions.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit;
}

$categories = getCategories($conn);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = sanitize($_POST['product_name'] ?? '');
    $productPrice = floatval($_POST['product_price'] ?? 0);
    $category_id = intval($_POST['product_category'] ?? 0);
    $featured = isset($_POST['featured']) ? 1 : 0;

    if (empty($productName) || $productPrice <= 0) {
        $error = 'Please provide a product name and price.';
    } elseif (empty($_FILES['product_image']['name'])) {
        $error = 'Please upload a product image.';
    } else {
        $uploadDir = __DIR__ . '/../assets/images/';
        $imageName = time() . '_' . basename($_FILES['product_image']['name']);
        $targetFile = $uploadDir . $imageName;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $check = getimagesize($_FILES['product_image']['tmp_name']);

        if ($check === false) {
            $error = 'Uploaded file is not a valid image.';
        } elseif ($_FILES['product_image']['size'] > 3000000) {
            $error = 'Image size is too large.';
        } elseif (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
            $error = 'Only JPG, JPEG, PNG, and GIF files are allowed.';
        } else {
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetFile)) {
                $stmt = $conn->prepare("INSERT INTO products (name, price, category_id, image, featured) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param('sdisi', $productName, $productPrice, $category_id, $imageName, $featured);
                if ($stmt->execute()) {
                    $success = 'Product added successfully.';
                } else {
                    $error = 'Error saving product: ' . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = 'Unable to upload the product image.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Admin Panel</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main class="container admin-page">
        <section class="page-heading">
            <h1>Add New Product</h1>
        </section>

        <?php if (!empty($error)): ?>
            <div class="error-box"><?php echo sanitize($error); ?></div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
            <div class="success-box"><?php echo sanitize($success); ?></div>
        <?php endif; ?>

        <form class="admin-form" action="<?= BASE_URL ?>/admin/add-product.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="product_name">Product Name</label>
                <input type="text" id="product_name" name="product_name" required>
            </div>
            <div class="form-group">
                <label for="product_price">Price</label>
                <input type="number" id="product_price" name="product_price" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="product_category">Category</label>
                <select id="product_category" name="product_category" required>
                    <option value="0">Select category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo sanitize($category['id']); ?>"><?php echo sanitize($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="product_image">Product Image</label>
                <input type="file" id="product_image" name="product_image" accept="image/*" required>
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" name="featured" value="1"> Featured Product
                </label>
            </div>
            <button class="button button-primary" type="submit">Add Product</button>
        </form>
    </main>
</body>
</html>