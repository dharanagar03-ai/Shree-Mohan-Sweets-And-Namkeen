<?php
session_start();
include('../includes/config.php');
include('../includes/functions.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit;
}

$query = "SELECT p.id, p.name, p.price, p.image, c.name AS category_name, p.featured, p.created_at FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Admin Panel</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<?php include('../includes/header.php'); ?>
<main class="container admin-page">
    <section class="page-heading">
        <h1>Manage Products</h1>
    </section>
    <div class="admin-actions">
        <a class="button button-primary" href="<?= BASE_URL ?>/admin/add-product.php">Add New Product</a>
        <a class="button button-secondary" href="<?= BASE_URL ?>/admin/dashboard.php">Dashboard</a>
    </div>
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Featured</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo sanitize($product['id']); ?></td>
                    <td><?php echo sanitize($product['name']); ?></td>
                    <td><?php echo sanitize($product['category_name'] ?: 'Uncategorized'); ?></td>
                    <td>₹<?php echo sanitize($product['price']); ?></td>
                    <td><?php echo $product['featured'] ? 'Yes' : 'No'; ?></td>
                    <td><img src="<?= BASE_URL ?>/assets/images/<?php echo sanitize($product['image']); ?>" alt="<?php echo sanitize($product['name']); ?>" style="width:80px;border-radius:12px;"></td>
                    <td>
                        <a class="button button-secondary" href="<?= BASE_URL ?>/admin/edit-product.php?id=<?php echo sanitize($product['id']); ?>">Edit</a>
                        <form action="<?= BASE_URL ?>/admin/delete-product.php" method="POST" data-confirm="Delete this product?" style="display:inline-block;">
                            <input type="hidden" name="id" value="<?php echo sanitize($product['id']); ?>">
                            <button type="submit" class="button">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</main>
<?php include('../includes/footer.php'); ?>
</body>
</html>
