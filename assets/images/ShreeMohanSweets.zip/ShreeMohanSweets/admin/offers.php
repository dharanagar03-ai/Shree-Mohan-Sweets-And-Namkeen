<?php
session_start();
include('../includes/config.php');
include('../includes/functions.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['action']) && $_POST['action'] === 'create') {
        $description = sanitize($_POST['description'] ?? '');
        $discount = floatval($_POST['discount'] ?? 0);
        $active = isset($_POST['active']) ? 1 : 0;
        $start_date = $_POST['start_date'] ?? date('Y-m-d');
        $end_date = $_POST['end_date'] ?? date('Y-m-d');

        if ($description && $discount > 0) {
            $stmt = $conn->prepare('INSERT INTO offers (description, discount, start_date, end_date, active) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('sdssi', $description, $discount, $start_date, $end_date, $active);
            $stmt->execute();
            $stmt->close();
            $success = 'Offer added successfully.';
        } else {
            $error = 'Please provide offer description and discount.';
        }
    }
    if (!empty($_POST['action']) && $_POST['action'] === 'delete' && !empty($_POST['offer_id'])) {
        $offer_id = intval($_POST['offer_id']);
        $stmt = $conn->prepare('DELETE FROM offers WHERE id = ?');
        $stmt->bind_param('i', $offer_id);
        $stmt->execute();
        $stmt->close();
        $success = 'Offer deleted successfully.';
    }
    if (!empty($_POST['action']) && $_POST['action'] === 'toggle' && !empty($_POST['offer_id'])) {
        $offer_id = intval($_POST['offer_id']);
        $active = isset($_POST['active']) && $_POST['active'] ? 1 : 0;
        $stmt = $conn->prepare('UPDATE offers SET active = ? WHERE id = ?');
        $stmt->bind_param('ii', $active, $offer_id);
        $stmt->execute();
        $stmt->close();
        $success = 'Offer status updated.';
    }
}

$offers_result = mysqli_query($conn, 'SELECT * FROM offers ORDER BY created_at DESC');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Offers - Admin Panel</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>

    <main class="container admin-page">
        <section class="page-heading">
            <h1>Manage Offers</h1>
        </section>

        <?php if (!empty($error)): ?>
            <div class="error-box"><?php echo sanitize($error); ?></div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
            <div class="success-box"><?php echo sanitize($success); ?></div>
        <?php endif; ?>

        <form class="admin-form" action="<?= BASE_URL ?>/admin/offers.php" method="POST">
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label for="description">Offer Description</label>
                <input type="text" id="description" name="description" required>
            </div>
            <div class="form-group">
                <label for="discount">Discount (%)</label>
                <input type="number" id="discount" name="discount" step="0.01" min="0" required>
            </div>
            <div class="form-group">
                <label for="start_date">Start Date</label>
                <input type="date" id="start_date" name="start_date" value="<?= date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label for="end_date">End Date</label>
                <input type="date" id="end_date" name="end_date" value="<?= date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label><input type="checkbox" name="active" value="1" checked> Active Offer</label>
            </div>
            <button class="button button-primary" type="submit">Add Offer</button>
        </form>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Description</th>
                    <th>Discount</th>
                    <th>Status</th>
                    <th>Dates</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($offer = mysqli_fetch_assoc($offers_result)): ?>
                    <tr>
                        <td><?php echo sanitize($offer['id']); ?></td>
                        <td><?php echo sanitize($offer['description']); ?></td>
                        <td><?php echo sanitize($offer['discount']); ?>%</td>
                        <td><?php echo $offer['active'] ? 'Active' : 'Inactive'; ?></td>
                        <td><?php echo sanitize($offer['start_date']); ?> - <?php echo sanitize($offer['end_date']); ?></td>
                        <td>
                            <form class="inline-form" action="<?= BASE_URL ?>/admin/offers.php" method="POST" data-confirm="Toggle this offer status?">
                                <input type="hidden" name="action" value="toggle">
                                <input type="hidden" name="offer_id" value="<?php echo sanitize($offer['id']); ?>">
                                <input type="hidden" name="active" value="<?php echo $offer['active'] ? '0' : '1'; ?>">
                                <button class="button button-secondary" type="submit"><?php echo $offer['active'] ? 'Deactivate' : 'Activate'; ?></button>
                            </form>
                            <form class="inline-form" action="<?= BASE_URL ?>/admin/offers.php" method="POST" data-confirm="Delete this offer?">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="offer_id" value="<?php echo sanitize($offer['id']); ?>">
                                <button class="button" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <?php include('../includes/footer.php'); ?>
</body>
</html>