# Shree Mohan Sweets & Namkeen Website

## Project Overview
This project is a complete management and customer ordering website for Shree Mohan Sweets & Namkeen. It allows customers to browse products, place orders, and provides an admin panel for managing products and orders.

## Features
- **Home Page**: Displays the shop logo, hero banner, tagline, featured products, offers section, and a WhatsApp order button.
- **Products Page**: Categorized product listings with images, names, prices, and "Add to Cart" functionality.
- **Cart and Checkout**: Customers can view their cart, enter their details, and select payment methods.
- **Admin Panel**: Admins can manage products, view orders, and handle offers and payments.
- **Responsive Design**: The website is mobile-friendly with a clean modern UI using the brand colors of pink, yellow, and white.

## File Structure
```
ShreeMohanSweets
├── admin
│   ├── add-product.php
│   ├── dashboard.php
│   ├── login.php
│   ├── offers.php
│   ├── orders.php
│   ├── payments.php
│   └── uploads
├── assets
│   ├── css
│   │   └── style.css
│   ├── js
│   │   └── script.js
│   └── images
├── includes
│   ├── config.php
│   ├── footer.php
│   ├── header.php
│   └── functions.php
├── index.php
├── products.php
├── cart.php
├── checkout.php
├── contact.php
├── about.php
├── database.sql
└── README.md
```

## Step-by-Step Instructions to Run the Project in WAMP using phpMyAdmin and localhost:

1. **Install WAMP Server**: Download and install WAMP Server from the official website. Ensure that Apache and MySQL services are running.

2. **Create Project Directory**: Navigate to the WAMP installation directory (usually `C:\wamp64\www\`) and create a new folder named `ShreeMohanSweets`.

3. **Add Project Files**: Copy the project files and folders (as per the structure above) into the `ShreeMohanSweets` directory.

4. **Set Up Database**:
   - Open your web browser and go to `http://localhost/phpmyadmin`.
   - Log in with the default credentials (username: root, password: [leave blank]).
   - Click on "Databases" and create a new database named `shreemohansweets`.
   - Select the newly created database and click on the "Import" tab.
   - Choose the `database.sql` file from your project directory and click "Go" to import the database structure.

5. **Configure Database Connection**: Open `includes/config.php` and update the database connection settings if necessary (host, username, password, database name).

6. **Access the Website**: Open your web browser and go to `http://localhost/ShreeMohanSweets/index.php` to view the home page.

7. **Admin Login**: To access the admin panel, navigate to `http://localhost/ShreeMohanSweets/admin/login.php` and log in with the admin credentials you set up.

8. **Test Functionality**: Test all functionalities, including product addition, cart operations, and order processing.

By following these steps, you should be able to successfully run the Shree Mohan Sweets & Namkeen website on your local WAMP server.