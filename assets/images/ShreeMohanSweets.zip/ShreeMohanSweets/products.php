<?php
include 'includes/config.php';
include 'includes/functions.php';

$query = "SELECT p.id, p.name, p.price, p.image, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC";
$result = mysqli_query($conn, $query);
if (!$result) {
    die("Products Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Shree Mohan Sweets and Namkeen</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<main class="container">
    <section class="page-heading">
        <h1>Our Products</h1>
        <p>Browse sweets, namkeen, gift boxes and festive favorites.</p>
    </section>

    <div class="product-grid">
        <?php while ($product = mysqli_fetch_assoc($result)): ?>
            <article class="product-card">
                <img src="<?= BASE_URL ?>/assets/images/<?php echo sanitize($product['image']); ?>" alt="<?php echo sanitize($product['name']); ?>">
                <div class="product-card-body">
                    <h3><?php echo sanitize($product['name']); ?></h3>
                    <p class="category"><?php echo sanitize($product['category_name'] ?? 'Uncategorized'); ?></p>
                    <p class="price">₹<?php echo sanitize($product['price']); ?></p>
                    <form class="product-card-form" method="POST" action="<?= BASE_URL ?>/cart_action.php">
                        <input type="hidden" name="product_id" value="<?php echo sanitize($product['id']); ?>">
                        <label for="quantity-<?php echo sanitize($product['id']); ?>">Quantity</label>
                        <input type="number" id="quantity-<?php echo sanitize($product['id']); ?>" name="quantity" value="1" min="1" max="20">
                        <button type="submit" name="action" value="add">Add to Cart</button>
                    </form>
                </div>
            </article>
        <?php endwhile; ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>