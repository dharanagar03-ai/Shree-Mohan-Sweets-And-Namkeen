<?php
include 'includes/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Shree Mohan Sweets and Namkeen</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<main class="container about-page">
    <section class="page-heading">
        <h1>About Shree Mohan Sweets and Namkeen</h1>
        <p>Serving tradition, flavor, and quality since 1979.</p>
    </section>

    <div class="about-grid">
        <div class="about-card">
            <h2>Our Story</h2>
            <p>We began as a family-owned sweet shop with a dream to bring authentic Indian sweets and namkeen to our community. Over four decades later, we still follow the same traditional recipes and fresh handmade methods.</p>
        </div>

        <div class="about-card">
            <h2>Our Philosophy</h2>
            <p>Every product is made with premium ingredients, care, and a commitment to taste. We believe in creating joyful moments through sweets and snacks that feel familiar and special.</p>
        </div>

        <div class="about-card">
            <h2>Why Trust Us</h2>
            <ul>
                <li>Over 40 years of experience</li>
                <li>Freshly prepared daily</li>
                <li>Trusted by families across the city</li>
                <li>Fast service and caring support</li>
            </ul>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>