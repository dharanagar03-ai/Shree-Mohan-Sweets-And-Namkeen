<?php
include 'includes/config.php';
include 'includes/functions.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $product_id => $quantity) {
        $product_id = intval($product_id);
        $quantity = intval($quantity);
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$product_id]);
        } else {
            $_SESSION['cart'][$product_id] = $quantity;
        }
    }
}

$cart_items = [];
$total_price = 0;
if (!empty($_SESSION['cart'])) {
    $cart_items = getCartItems($conn, array_keys($_SESSION['cart']));
    foreach ($cart_items as $item) {
        $total_price += $item['price'] * $_SESSION['cart'][$item['id']];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Shree Mohan Sweets and Namkeen</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<main class="container">
    <section class="page-heading">
        <h1>Your Cart</h1>
    </section>

    <?php if (empty($cart_items)): ?>
        <div class="empty-state">
            <p>Your cart is empty. <a href="<?= BASE_URL ?>/products.php">Browse products</a> to add items.</p>
        </div>
    <?php else: ?>
        <form method="POST" action="<?= BASE_URL ?>/cart.php">
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td><?php echo sanitize($item['name']); ?></td>
                            <td>₹<?php echo sanitize($item['price']); ?></td>
                            <td>
                                <input type="number" name="quantity[<?php echo sanitize($item['id']); ?>]" value="<?php echo sanitize($_SESSION['cart'][$item['id']]); ?>" min="0">
                            </td>
                            <td>₹<?php echo sanitize($item['price'] * $_SESSION['cart'][$item['id']]); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="cart-actions">
                <button type="submit" name="update_cart" class="button">Update Cart</button>
                <a class="button button-primary" href="<?= BASE_URL ?>/checkout.php">Proceed to Checkout</a>
            </div>
            <div class="cart-total">
                <h2>Total: ₹<?php echo sanitize($total_price); ?></h2>
            </div>
        </form>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>