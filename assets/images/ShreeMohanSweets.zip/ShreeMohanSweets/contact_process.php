<?php
include 'includes/config.php';
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/contact.php');
    exit;
}

$name = sanitize($_POST['name'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$message = sanitize($_POST['message'] ?? '');
$error = '';

if (empty($name) || empty($email) || empty($message)) {
    $error = 'Please fill in all fields.';
} else {
    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $name, $email, $message);
    if ($stmt->execute()) {
        $success = 'Thank you! Your message has been received. We will contact you soon.';
    } else {
        $error = 'There was an issue sending your message. Please try again later.';
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Submitted - Shree Mohan Sweets</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<?php include 'includes/header.php'; ?>
<main class="container contact-page">
    <section class="page-heading">
        <h1>Contact Request</h1>
    </section>
    <div class="success-box">
        <?php if (!empty($success)): ?>
            <p><?php echo sanitize($success); ?></p>
        <?php else: ?>
            <p><?php echo sanitize($error); ?></p>
        <?php endif; ?>
    </div>
    <div style="margin-top:24px;">
        <a class="button button-primary" href="<?= BASE_URL ?>/contact.php">Return to Contact Page</a>
    </div>
</main>
<?php include 'includes/footer.php'; ?>
</body>
</html>
