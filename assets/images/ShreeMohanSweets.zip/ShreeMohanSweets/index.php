<?php
include 'includes/config.php';
include 'includes/functions.php';

$featuredQuery = "SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.featured = 1 ORDER BY p.created_at DESC LIMIT 6";
$featuredResult = mysqli_query($conn, $featuredQuery);
if (!$featuredResult) {
    die("Products Query Error: " . mysqli_error($conn));
}
$featured_products = mysqli_fetch_all($featuredResult, MYSQLI_ASSOC);
$active_offers = getActiveOffers($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shree Mohan Sweets and Namkeen</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<section class="hero-banner">
    <div class="container hero-content">
        <span class="eyebrow">Since 1979</span>
        <h1>Delicious sweets and namkeen made fresh every day</h1>
        <p>Enjoy authentic flavor, handcrafted recipes, and fast delivery across the city.</p>
        <a class="button button-primary" href="<?= BASE_URL ?>/products.php">View Products</a>
    </div>
</section>

<section class="featured-products container">
    <div class="section-heading">
        <h2>Featured Products</h2>
        <p>Handpicked sweets and snacks ready for your next celebration.</p>
    </div>
    <div class="product-grid">
        <?php if (!empty($featured_products)): ?>
            <?php foreach ($featured_products as $product): ?>
                <article class="product-card">
                    <img src="<?= BASE_URL ?>/assets/images/<?php echo sanitize($product['image']); ?>" alt="<?php echo sanitize($product['name']); ?>">
                    <div class="product-card-body">
                        <h3><?php echo sanitize($product['name']); ?></h3>
                        <p class="category"><?php echo sanitize($product['category_name'] ?: 'All Snacks'); ?></p>
                        <p class="price">₹<?php echo sanitize($product['price']); ?></p>
                        <form method="POST" action="<?= BASE_URL ?>/cart_action.php" class="product-card-form">
                            <input type="hidden" name="product_id" value="<?php echo sanitize($product['id']); ?>">
                            <input type="number" name="quantity" value="1" min="1" max="10" aria-label="Quantity">
                            <button type="submit" name="action" value="add">Add to Cart</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No featured products available at the moment.</p>
        <?php endif; ?>
    </div>
</section>

<section class="offers container">
    <div class="section-heading">
        <h2>Current Offers</h2>
        <p>Don't miss these special savings.</p>
    </div>
    <div class="offers-list">
        <?php if (!empty($active_offers)): ?>
            <?php foreach ($active_offers as $offer): ?>
                <div class="offer-card">
                    <p><?php echo sanitize($offer['description']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="offer-card">
                <p>Check back soon for fresh offers.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="about-preview container">
    <div class="about-card">
        <h2>Trusted Sweetmakers Since 1979</h2>
        <p>From classic laddus to crunchy namkeen, we use quality ingredients and recipes passed down through generations.</p>
        <a class="button button-secondary" href="<?= BASE_URL ?>/about.php">Learn More</a>
    </div>
</section>

<a href="https://wa.me/919313202040" class="whatsapp-button" target="_blank">Order via WhatsApp</a>

<?php include 'includes/footer.php'; ?>
<script src="<?= BASE_URL ?>/assets/js/script.js"></script>
</body>
</html>
