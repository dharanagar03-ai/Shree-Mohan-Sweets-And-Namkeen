<?php
include 'includes/config.php';
include 'includes/functions.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$cart_items = [];
$total_price = 0;
if (!empty($_SESSION['cart'])) {
    $cart_items = getCartItems($conn, array_keys($_SESSION['cart']));
    foreach ($cart_items as $item) {
        $total_price += $item['price'] * $_SESSION['cart'][$item['id']];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $payment_method = sanitize($_POST['payment_method'] ?? '');

    if (empty($name) || empty($phone) || empty($address) || empty($payment_method)) {
        $error = "All fields are required.";
    } elseif (empty($cart_items)) {
        $error = "Your cart is empty. Please add products before checkout.";
    } else {
        $stmt = $conn->prepare("INSERT INTO orders (customer_name, phone, address, payment_method, total_amount, status) VALUES (?, ?, ?, ?, ?, 'Pending')");
        $stmt->bind_param('ssssd', $name, $phone, $address, $payment_method, $total_price);
        if ($stmt->execute()) {
            $order_id = $stmt->insert_id;
            $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
            foreach ($cart_items as $item) {
                $quantity = $_SESSION['cart'][$item['id']];
                $stmt_item->bind_param('iiid', $order_id, $item['id'], $quantity, $item['price']);
                $stmt_item->execute();
            }
            $payment_status = $payment_method === 'Cash on Delivery' ? 'Pending' : 'Completed';
            $stmt_payment = $conn->prepare("INSERT INTO payments (order_id, amount, method, status) VALUES (?, ?, ?, ?)");
            $stmt_payment->bind_param('idss', $order_id, $total_price, $payment_method, $payment_status);
            $stmt_payment->execute();
            unset($_SESSION['cart']);
            $success = "Order Confirmed! Your Order ID is: $order_id";
            $stmt_item->close();
            $stmt_payment->close();
        } else {
            $error = "Error processing your order. Please try again.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Shree Mohan Sweets and Namkeen</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<main class="container">
    <section class="page-heading">
        <h1>Checkout</h1>
    </section>

    <?php if (!empty($success)): ?>
        <div class="success-box">
            <h2><?php echo sanitize($success); ?></h2>
            <p>Your order has been placed successfully.</p>
            <a class="button button-primary" href="<?= BASE_URL ?>/products.php">Continue Shopping</a>
        </div>
    <?php else: ?>
        <?php if (!empty($error)): ?>
            <div class="error-box"><?php echo sanitize($error); ?></div>
        <?php endif; ?>

        <?php if (empty($cart_items)): ?>
            <div class="empty-state">
                <p>Your cart is empty. <a href="<?= BASE_URL ?>/products.php">Add products to continue</a>.</p>
            </div>
        <?php else: ?>
            <div class="checkout-summary">
                <h2>Order Summary</h2>
                <ul>
                    <?php foreach ($cart_items as $item): ?>
                        <li><?php echo sanitize($item['name']); ?> × <?php echo sanitize($_SESSION['cart'][$item['id']]); ?> = ₹<?php echo sanitize($item['price'] * $_SESSION['cart'][$item['id']]); ?></li>
                    <?php endforeach; ?>
                </ul>
                <p class="checkout-total">Total: ₹<?php echo sanitize($total_price); ?></p>
            </div>

            <form method="POST" action="<?= BASE_URL ?>/checkout.php" class="checkout-form">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" name="phone" id="phone" required>
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea name="address" id="address" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="payment_method">Payment Method</label>
                    <select name="payment_method" id="payment_method" required>
                        <option value="Cash on Delivery">Cash on Delivery</option>
                        <option value="UPI">UPI</option>
                        <option value="Online Payment">Online Payment</option>
                    </select>
                </div>
                <button class="button button-primary" type="submit">Confirm Order</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>