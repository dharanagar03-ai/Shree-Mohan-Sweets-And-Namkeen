<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
?>
<header class="site-header">
    <div class="container header-inner">
        <a class="logo-link" href="<?= BASE_URL ?>/index.php">
            <img class="logo-img" src="<?= BASE_URL ?>/assets/images/logo.jpeg" alt="Shree Mohan Sweets & Namkeen Logo">
            <div class="logo-text">
                <h1>Shree Mohan Sweets & Namkeen</h1>
                <p>Since 1979 | Sweetness for every celebration</p>
            </div>
        </a>

        <nav class="main-nav">
            <ul>
                <li><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li><a href="<?= BASE_URL ?>/products.php">Products</a></li>
                <li><a href="<?= BASE_URL ?>/cart.php">Cart (<?= $cart_count ?>)</a></li>
                <li><a href="<?= BASE_URL ?>/contact.php">Contact</a></li>
                <li><a href="<?= BASE_URL ?>/about.php">About Us</a></li>
                <?php if (isset($_SESSION['admin_logged_in'])): ?>
                    <li><a href="<?= BASE_URL ?>/admin/dashboard.php">Admin Panel</a></li>
                    <li><a href="<?= BASE_URL ?>/admin/logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="<?= BASE_URL ?>/admin/login.php">Admin Login</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>
