<?php
function sanitize($value) {
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

function getCartItems($conn, $productIds = []) {
    if (empty($productIds)) {
        return [];
    }

    $ids = array_map('intval', $productIds);
    $idList = implode(',', $ids);
    $sql = "SELECT id, name, price, image FROM products WHERE id IN ($idList)";
    $result = mysqli_query($conn, $sql);
    return $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

function getTotalProducts($conn) {
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM products");
    return $result ? intval(mysqli_fetch_assoc($result)['total']) : 0;
}

function getTotalOrders($conn) {
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders");
    return $result ? intval(mysqli_fetch_assoc($result)['total']) : 0;
}

function getTotalRevenue($conn) {
    $result = mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) AS total FROM orders");
    return $result ? floatval(mysqli_fetch_assoc($result)['total']) : 0;
}

function getCategories($conn) {
    $result = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
    return $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

function getCategoryName($conn, $categoryId) {
    if (empty($categoryId)) {
        return 'Uncategorized';
    }
    $stmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
    $stmt->bind_param('i', $categoryId);
    $stmt->execute();
    $stmt->bind_result($name);
    $stmt->fetch();
    $stmt->close();
    return $name ?: 'Uncategorized';
}

function getActiveOffers($conn) {
    $result = mysqli_query($conn, "SELECT * FROM offers WHERE active = 1 ORDER BY created_at DESC");
    return $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

function getOrderItems($conn, $orderId) {
    $stmt = $conn->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    $items = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
    $stmt->close();
    return $items;
}
?>
