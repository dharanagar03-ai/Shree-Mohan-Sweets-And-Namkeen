<footer class="site-footer">
    <div class="container footer-inner">
        <div class="footer-details">
            <p>&copy; <?= date('Y'); ?> Shree Mohan Sweets and Namkeen. All rights reserved.</p>
            <p><a href="mailto:info@shreemohansweets.com">info@shreemohansweets.com</a> | Phone: <a href="tel:+911234567890">+91 123 456 7890</a></p>
        </div>
        <div class="footer-links">
            <a href="https://www.facebook.com/shreemohansweets" target="_blank">Facebook</a>
            <a href="https://www.instagram.com/shreemohansweets" target="_blank">Instagram</a>
            <a href="https://wa.me/911234567890" target="_blank">WhatsApp</a>
        </div>
    </div>
</footer>
